theduels
========

TheDuels is a game based on playing duels with other players. The results are then submitted into system and this generates the score.
