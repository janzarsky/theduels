<nav class="menu">
	<a href="<?php echo base_url('/setup'); ?>">
		<span class="menu__item">
			Nastavení
		</span>
	</a>
	<a href="<?php echo base_url('/admin'); ?>">
		<span class="menu__item">
			Admin
		</span>
	</a>
	<a href="<?php echo base_url('/'); ?>">
		<span class="menu__item">
			Public
		</span>
	</a>
</nav>