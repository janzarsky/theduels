<div class="content">
	<header class="content__header">
		Chyba!
	</header>
	
	<div class="main main--center">
		<div class="message">
			<?php echo $message; ?>
		</div>
	</div>
</div>