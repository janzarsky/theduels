	<?php if (isset($script)) { ?>
		<script src="<?php echo base_url('/media/js/' . $script); ?>"></script>
	<?php } ?>
</body>
</html>